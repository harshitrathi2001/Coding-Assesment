package com.codingassesment.viewmodel

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.codingassesment.pojo.UserInfo
import java.util.*

class MainViewModel : ViewModel() {

    val result: MutableLiveData<UserInfo> = MutableLiveData()

    fun calculateAge(year: Int, month: Int, day: Int): String {
        val dob: Calendar = Calendar.getInstance()
        val today: Calendar = Calendar.getInstance()
        dob.set(year, month, day)
        var age: Int = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR)
        if (today.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR)) {
            age--
        }
        val ageInt = age
        return ageInt.toString()
    }

    fun setItem(item: UserInfo?) {
        result.value = item
    }

}