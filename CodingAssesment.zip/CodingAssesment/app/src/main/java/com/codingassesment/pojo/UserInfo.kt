package com.codingassesment.pojo

data class UserInfo (val firstName: String, val secondName: String, val age: String)