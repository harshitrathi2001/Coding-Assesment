package com.codingassesment.ui.main

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.DatePicker
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import androidx.lifecycle.ViewModelProvider
import com.codingassesment.R
import com.codingassesment.pojo.UserInfo
import com.codingassesment.viewmodel.MainViewModel
import java.util.*


class MainFragment : Fragment() {

    companion object {
        fun newInstance() = MainFragment()
    }

    private lateinit var viewModel: MainViewModel

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.main_fragment, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(requireActivity()).get(MainViewModel::class.java)

        val picker = view!!.findViewById<DatePicker>(R.id.picker)
        picker.maxDate = Date().time

        val calculate = view!!.findViewById<Button>(R.id.calculate)
        calculate.setOnClickListener {
            viewModel.setItem(UserInfo("Harshit", "Rathi",
                    viewModel.calculateAge(picker.year, picker.month, picker.dayOfMonth)))

            val ft: FragmentTransaction = fragmentManager!!.beginTransaction()
            val secondFragment: Fragment = SecondFragment.newInstance()
            ft.replace(R.id.container, secondFragment)
            ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
            ft.commit()
        }
    }

}