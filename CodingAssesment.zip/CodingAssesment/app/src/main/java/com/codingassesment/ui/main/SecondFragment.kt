package com.codingassesment.ui.main

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.lifecycle.Observer
import com.codingassesment.R
import com.codingassesment.viewmodel.MainViewModel

class SecondFragment : Fragment() {

    companion object {
        fun newInstance() = SecondFragment()
    }

    private lateinit var viewModel: MainViewModel

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View {
        return inflater.inflate(R.layout.second_fragment, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(requireActivity()).get(MainViewModel::class.java)

        viewModel.result.observe(requireActivity(), Observer {userInfo ->
            userInfo?:return@Observer

            view!!.findViewById<TextView>(R.id.first_name).apply {
                text = userInfo.firstName
            }

            view!!.findViewById<TextView>(R.id.second_name).apply {
                text = userInfo.secondName
            }

            view!!.findViewById<TextView>(R.id.age_name).apply {
                text = userInfo.age
            }
        })
    }

}